
<?php $__env->startSection('section'); ?>
<br>
<div class="img">
	<img src="/pic/bh.jpeg">
</div>


<br>
<br>
<br>
<p>
What is Barangay Health Center?
<br>
Brgy.Health Care Management System is  a community-based and patient-directed organization.<br>
Its goal is to provide first aid, maternal and child health care,diagnosis of social diseases and other basic health services to all the members of the community it is serving.Barangay Health Center is Located @ Calepaan,Asingan,Pangasinan. Where check-ups are free for everyone.Every
Monday, Wednesday and Friday. Also midwife, nurse and Barangay Health Workers are very approachable. </p>

<br>
<br>
<br>
<div class="row">
<img src="/pic/p1.jpg"  >
<img src="/pic/p3.jpg"  >
<img src="pic/p4.jpg"  >
<img src="pic/p5.jpg"  >
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\center\resources\views/about.blade.php ENDPATH**/ ?>