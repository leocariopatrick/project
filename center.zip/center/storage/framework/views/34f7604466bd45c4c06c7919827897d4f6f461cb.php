
<?php $__env->startSection('section'); ?>
<br>
<h1>Daily Check Up</h1>
	<form action="" method="POST">

		<table style="width: 100%">
	<tr>
		<th>Date</th>
		<th>Folder Number</th>
		<th>Fullname</th>
		<th>Age</th>
		<th>CC</th>
		<th>Rx</th>
	</tr>
	<tr>
		<td><input type="text" name="datee" ></td>
		<td><input type="text" name="fold_no"></td>
		<td><input type="text" name="name"></td>
		<td><input type="text" name="age"></td>
		<td><input type="text" name="pres_cc"></td>
		<td><input type="text" name="rx"></td>
	</tr>

</table>
	<input type="submit" name="btnadd" value="Add" class="add">

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jewel Joyce Ramos\Desktop\center\resources\views/insertData.blade.php ENDPATH**/ ?>