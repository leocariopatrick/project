<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
	}
	body{
		background: #FFBB98;
	}
	header{
		padding: 30px;
		background: #FBE0C3;
		text-align: center;
		font-size: 25px;
		font-family: sans-serif;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #FBE0C3;
	}
	.nav
	{
		text-decoration: none;
		padding: 20px;
		color: black;
		font-size: 15px;
		font-family: sans-serif;
	}
	img{
		width: 980px;
		height: 450px;
		margin-left:70px; 

	}h1{
		text-align: center;
		font-family: sans-serif;
		font-size: 25px;
	}
	.search{
		margin: 10px 0px 10px 0px;
	}
	.search label{
		padding-top: 50px;
		display: block;
		text-align: center;
		margin: 3px;
	}
	.search input{
		margin-left: 450px;
		height: 30px;
		width: 43%;
		padding: 5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.btn{
		margin-left: 660px;
		padding: 10px;
		width: 13%;
		font-size: 15px;
		color: white;
		background-color: #7D8E95;
		border: none;
		border-radius: 5px;
	}
	.add{
		margin-left: 660px;
		padding: 10px;
		width: 13%;
		font-size: 15px;
		color: white;
		background-color: #7D8E95;
		border: none;
		border-radius: 5px;
	}
	table, th, td{
		border: 2px solid black;
		border-collapse: collapse;
	}
	th td{
		padding: 5px;
		text-align: center;
	}
	footer{
		margin-top: 340px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
	

.img-img {
  /* The image used */
  background-image: url("/pic/img.jpg");
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
 
  
}

/* Add styles to the form container */


	.header{
		width: 30%;
		margin: 50px auto 0px;
		color: white;
		background: #5F9EA0;
		text-align: center;
		border: 1px solid:#B0C4DE;
		border-bottom: none;
		border-radius: 10px 10px 0px 0px;
		padding: 20px;
	}
	form{
		width: 30%;
		margin: 0px auto;
		padding: 20px;
	
		margin-right: 130px;
		border-radius: 0px 0px 10px 10px;
	}
	.input-group{
		margin: 10px 0px 10px 0px;
	}
	.input-group label{
		display: block;
		text-align: left;
		margin: 3px;
	}
	.input-group input{
		height: 30px;
		width: 93%;
		padding: 5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.btn{
		padding: 10px;
		font-size: 15px;
		color: white;
		background: #5F9EA0;
		border: none;
		border-radius: 5px;
	}
	p{
color: black;
		font-size: 20px;
		font-family: sans-serif;

	}
	h1{
		color: black;
		font-size: 20px;
		font-family: sans-serif;
		text-align: center;
	}
	h2{
		color: black;
		font-size: 25px;
		font-family: 'Brush Script MT', cursive;
		text-align: center;
	}
	
	
	.row img{
    
       margin-left: 200px;
  padding:5px;
    width: 350px;
    height: 150px


}
	footer{
		margin-top: 30px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
</style>
<body>
<header><strong>Calepaan Health Center</strong></header>
<br>
<br>
<nav>
	<a href="home" class="nav">Home</a>
	<a href="CheckUp" class="nav">Check Up</a>
	<a href="about" class="nav">About</a>
</nav>
	<section>
		<?php echo $__env->yieldContent('section'); ?>;
	</section>
	<footer>Copyright &copy; 2020</footer>
</body>
</html><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\center\resources\views//master.blade.php ENDPATH**/ ?>