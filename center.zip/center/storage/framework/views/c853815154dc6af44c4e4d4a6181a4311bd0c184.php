
<?php $__env->startSection('section'); ?>

<h1> 
<br>
<div class=" img-img">
	<form method="POST" action="reg.php" class="container">
	<h1>Register</h1>
		<div class="input-group">
		<label>Username</label>
		<input type="text" name="username">
		</div>
		<div class="input-group">
		<label>Email</label>
		<input type="text" name="email">
		</div>
		<div class="input-group">
		<label>Password</label>
		<input type="password" name="pass">
		</div>
		<div class="input-group">
		<label>Confirm Password</label>
		<input type="password" name="cpass">
		</div>
		<div class="input-group">
			<button type="submit" name="register" class="btn">Register</button>
		</div>

		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
	</form>
	</div>
<br>
	<p>“A resource for everyday life, not the objective of living. Health is a positive concept emphasizing social and personal resources, as well as physical capacities.”
    This means that health is a resource to support an individual’s function in wider society, rather than an end in itself. A healthful lifestyle provides the means to lead a full life with meaning and purpose.
    Your health is at the center of your life. Every part of your life relies on you having good health.</p>
    <br>
	<h2>Maintaining good health should be the primary focus of everyone. 
	-Sangram Singh</h2>
<br>
<div class="row">
<img src="/pic/hw.jpg"  >
<img src="/pic/pic7.jpg"  >

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\center\resources\views/home.blade.php ENDPATH**/ ?>