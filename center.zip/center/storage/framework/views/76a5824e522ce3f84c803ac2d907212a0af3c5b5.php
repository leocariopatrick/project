
<?php $__env->startSection('section'); ?>
<form action="insertData" method="get">
	<div class="search">
		<label>Search Folder Number</label><input type="search" name="fold_no" placeholder="Search Folder Number">
		<br>
		<input type="submit" name="btnsearch" value="search" class="btn">
	</div>
		<br>
	</form>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\center\resources\views/CheckUp.blade.php ENDPATH**/ ?>