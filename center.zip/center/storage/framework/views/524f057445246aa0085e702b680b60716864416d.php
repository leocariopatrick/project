
<?php $__env->startSection('section'); ?>
<br>
<h1>Personal Data's</h1>
<center>
	<div>
		<form action="" method="POST">
		<?php echo csrf_field(); ?> 

		<label>Date: </label><input type="text" name="date" ><br>
				<label>Folder Number: </label><input type="text" name="fold_no"><br>
				<label>Fullname: </label><input type="text" name="name"><br>
				<label>Age: </label><input type="text" name="age"><br>
				<label>Prescription: </label><input type="text" name="pres_cc"><br>
				<label>Rx: </label><input type="text" name="rx"><br>

				<input type="submit" name="btn-add" value="Add"><br>

	</form>
	</div>
</center>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('footer'); ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\center\resources\views/addData.blade.php ENDPATH**/ ?>