<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/about',[HomeController::class,'about']);

Route::get('/addData',[HomeController::class,'addData']);

Route::post('/addData',[HomeController::class,'insertD']);

Route::get('/CheckUp',[HomeController::class,'CheckUp']);


Route::get('/home',[HomeController::class,'home']);

Route::get('/insertData',[HomeController::class,'insertData']);

Route::get('/search', 'HomeController@search');
Route::resource('posts','HomeController');


