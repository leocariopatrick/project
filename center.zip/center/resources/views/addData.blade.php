@extends('layout.master')
@section('section')
<br>
<h1>Personal Data's</h1>
<center>
	<div>
		<form action="" method="POST">
		@csrf {{-- cross site request forgeries --}}

		<label>Date: </label><input type="text" name="date" ><br>
				<label>Folder Number: </label><input type="text" name="fold_no"><br>
				<label>Fullname: </label><input type="text" name="name"><br>
				<label>Age: </label><input type="text" name="age"><br>
				<label>Prescription: </label><input type="text" name="pres_cc"><br>
				<label>Rx: </label><input type="text" name="rx"><br>

				<input type="submit" name="btn-add" value="Add"><br>

	</form>
	</div>
</center>
	@endsection
	@section('footer')
	@endsection