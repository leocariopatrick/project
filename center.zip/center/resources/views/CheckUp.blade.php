@extends('layout.master')
@section('section')
<form action="insertData" method="get">
	<div class="search">
		<label>Search Folder Number</label><input type="search" name="fold_no" placeholder="Search Folder Number">
		<br>
		<input type="submit" name="btnsearch" value="search" class="btn">
	</div>
		<br>
	</form>
@endsection		