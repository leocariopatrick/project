@extends('layout.master')
@section('section')
<br>
<h1>Daily Check Up</h1>
<table>
	<tr>
		<th>Date</th>
		<th>Folder Number</th>
		<th>Fullname</th>
		<th>Age</th>
		<th>CC</th>
		<th>Rx</th>
	</tr>
			@foreach($data as $datas)
			<tr>
				<td>{{ $datas->datee }}</td>
				<td>{{ $datas->fold_no }}</td>
				<td>{{ $datas->name }}</td>
				<td>{{ $datas->age }}</td>
				<td>{{ $datas->pres_cc }}</td>
				<td>{{ $datas->rx }}</td>
			</tr>
			@endforeach
</table><br>
<br>
	<a href="addData" class="add">ADD</a>
</form>
@endsection