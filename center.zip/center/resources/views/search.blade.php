@extends('layout.master')
@section('section')
<br>
<h1>Daily Check Up</h1>
<table>
	<tr>
		<th>Date</th>
		<th>Folder Number</th>
		<th>Fullname</th>
		<th>Age</th>
		<th>CC</th>
		<th>Rx</th>
	</tr>
			@foreach($posts as $post)
			<tr>
				<td>{{ $post->datee }}</td>
				<td>{{ $post->fold_no }}</td>
				<td>{{ $post->name }}</td>
				<td>{{ $post->age }}</td>
				<td>{{ $post->pres_cc }}</td>
				<td>{{ $post->rx }}</td>
			</tr>
			@endforeach
</table><br>
<br>
	<a href="addData" class="add">ADD</a>
</form>
@endsection