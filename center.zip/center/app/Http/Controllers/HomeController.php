<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class HomeController extends Controller
{

           public function about(){
             return view('about');
         }
         public function addData(){
           $data = DB::select("SELECT * FROM tblcheckup");
          return view('addData',['data' => $data]);
        }
             public function insertD(Request $request){
          $date = $request->input('date');
          $fold_no = $request->input('fold_no');
          $name = $request->input('name');
          $age = $request->input('age');
          $pres_cc = $request->input('pres_cc');
          $rx = $request->input('rx');
          DB::insert("INSERT INTO tblcheckup(datee,fold_no,name,age,pres_cc,rx) VALUES(?,?,?,?,?,?)",[$date,$fold_no,$name,$age,$pres_cc,$rx]);
           $data = DB::select("SELECT * FROM tblcheckup");
          return view('addData',['data' => $data]);
         }
         public function CheckUp(){
    $search = DB::select("SELECT * FROM tblcheckup");
          return view('CheckUp',['search' => $search]);
}

         public function home(){
            return view('home');
         }
         public function insertData(){
        $data = DB::select("SELECT * FROM tblcheckup");
          return view('insertData',['data' => $data]);
        }
        public function Search(Request $request){
          $search =$request->get('search');
          $posts = DB::table('posts')->where('fold_no','like', '%'.$search
            .'%')->paginate(1);
          return view('CheckUp',['posts' =>$posts]);         

 }
}